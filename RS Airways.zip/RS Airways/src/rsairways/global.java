/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package rsairways;

/**
 *
 * @author Open
 */
public class global {
static String userid,username,name,passport,dob,gender,email,mobile,state,pref,secque,secans,rscash,time;
}
